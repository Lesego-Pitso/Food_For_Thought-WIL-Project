using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WIL_Project_v2.Pages
{
    public class MissionPageModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
