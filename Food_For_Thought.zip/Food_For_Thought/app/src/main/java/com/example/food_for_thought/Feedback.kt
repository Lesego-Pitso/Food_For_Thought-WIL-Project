package com.example.food_for_thought

data class Feedback(var Feed: String?= null)
