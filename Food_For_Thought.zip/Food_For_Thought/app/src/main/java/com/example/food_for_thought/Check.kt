package com.example.food_for_thought

data class Check(var stat: String?= null)