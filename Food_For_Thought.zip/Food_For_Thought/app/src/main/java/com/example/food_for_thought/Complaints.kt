package com.example.food_for_thought

data class Complaints(var Date: String?= null, var CName: String?= null,
                      var CEmail: String?= null, var About: String?= null,
                        var PName: String? = null, var CDetail: String?= null) {

}
