package com.example.food_for_thought

data class User(var Name: String?= null, var Email: String ?=null, var Number: String? = null, var Work: String?= null )
